#pragma once

typedef struct {
    char name[50];
    char continent[50];
    double population;
} Country;

Country createCountry(char *name, char *continent, double population);
char* getContinent(Country* p);
char* getName(Country* p);
double getPopupation(Country* p);
void toString(Country p);
