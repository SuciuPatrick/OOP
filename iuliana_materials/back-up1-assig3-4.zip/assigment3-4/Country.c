//
// Created by Suciu Patrick on 2019-03-12.
//

#include <stdio.h>
#include "Country.h"
#include <string.h>
#include <stdio.h>

Country createCountry(char *new_name, char *new_continent, double new_population)
{
    Country c;

    strcpy(c.name, new_name);
    strcpy(c.continent, new_continent);
    c.population = new_population;

    return c;
}

char* getName(Country* p)
{
    return p->name;
}

char* getContinent(Country* p)
{
    return p->continent;
}

double getPopupation(Country* p)
{
    return p->population;
}

void toString(Country p)
{
    printf("Name = %s, continent = %s, popupation = %f\n", p.name, p.continent, p.population);
}