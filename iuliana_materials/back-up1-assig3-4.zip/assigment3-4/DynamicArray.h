#pragma once
#include "Country.h"

typedef Country TElement;

typedef struct {
    TElement *elems;
    int length;
    int capacity;

} DynamicArray;

void add(TElement value, DynamicArray *da);
void resize(DynamicArray* da);
void destroy(DynamicArray* da);
DynamicArray* createDynamicArray(int capacity);
void ft_remove(char *country, DynamicArray *da);
void printOrderedCountries(DynamicArray *da, char *nameContinent);
void printCountriesContaingStr(DynamicArray *da, char* sub);
void migration(DynamicArray *da, char *country, int peopleMigrating, char *migratingToCountry);